const clubsList = [
  /* list of clubs, WCE */ "Walchand Linux Users' Group",
  "Association of Computer Science and Engineering Students",
  "Student Association of Information Technology",
  "Google Developer Students' Club",
  "ACM Student Chapter",
];

export default clubsList;
