const departmentList = [
  "Civil Engineering",
  "Mechanical Engineering",
  "Electrical Engineering",
  "Electronics Engineering",
  "Computer Science and Engineering",
  "Information Technology",
  "WCE",
];

export default departmentList;
