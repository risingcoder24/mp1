# wce-resource-tracker

Here's a demo on how to use this application: https://youtu.be/HKbtxdxrvo0

Application Link(APK File): https://expo.dev/artifacts/eas/4UxbmD7uFYku7PECwGQvni.apk

If you find any issue and have a fix, please raise a pull request.
